#include"Jagoda.h"
Jagoda::Jagoda(int xt, int yt)
{
	x = xt;
	y = yt;
	symbol = 'j';
	sila = 99;
	numer_enum = 3;
	wykonal_ruch = 1;
	zycie = 0;
}