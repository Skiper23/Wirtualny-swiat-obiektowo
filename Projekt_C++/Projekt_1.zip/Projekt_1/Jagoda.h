#pragma once
#include "Roslina.h"
class Jagoda : public Roslina
{
public:
	Jagoda(int x, int y);

};
