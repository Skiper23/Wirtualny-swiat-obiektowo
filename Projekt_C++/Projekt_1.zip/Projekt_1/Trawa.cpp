#include"Trawa.h"
Trawa::Trawa(int xt, int yt)
{
	x = xt;
	y = yt;
	symbol = 't';
	sila = 0;
	numer_enum = 0;
	wykonal_ruch = 1;
	zycie = 0;
}