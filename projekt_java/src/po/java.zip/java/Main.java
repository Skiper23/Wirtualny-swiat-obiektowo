package po.java;
import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Okienko okno= new Okienko();
        okno.createMenu();
    }

}
